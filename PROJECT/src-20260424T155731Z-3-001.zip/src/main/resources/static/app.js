document.addEventListener('DOMContentLoaded', () => {
    // Elements
    const jobForm = document.getElementById('jobForm');
    const jobList = document.getElementById('jobList');
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');

    // --- HOME PAGE LOGIC (index.html) ---
    if (jobList) {
        fetchJobs(); // Load jobs on page load

        searchBtn.addEventListener('click', () => {
            fetchJobs(searchInput.value);
        });

        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                fetchJobs(searchInput.value);
            }
        });
    }

    // --- POST JOB LOGIC (post-job.html) ---
    if (jobForm) {
        jobForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const jobData = {
                title: document.getElementById('title').value,
                company: document.getElementById('company').value,
                location: document.getElementById('location').value,
                salary: document.getElementById('salary').value,
                description: document.getElementById('description').value
            };

            try {
                const response = await fetch('/api/jobs', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(jobData)
                });

                if (response.ok) {
                    jobForm.reset();
                    document.getElementById('successMessage').style.display = 'block';
                    // Hide success message after 4 seconds
                    setTimeout(() => {
                        document.getElementById('successMessage').style.display = 'none';
                    }, 4000);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to post job. Please try again.');
            }
        });
    }

    // --- SHARED FUNCTIONS ---
    async function fetchJobs(searchQuery = '') {
        try {
            const url = searchQuery ? `/api/jobs?search=${encodeURIComponent(searchQuery)}` : '/api/jobs';
            const response = await fetch(url);
            const jobs = await response.json();
            
            jobList.innerHTML = '';

            if (jobs.length === 0) {
                jobList.innerHTML = `
                    <div class="card" style="text-align: center; color: var(--text-muted);">
                        <p>No jobs found. Try adjusting your search.</p>
                    </div>`;
                return;
            }

            jobs.forEach(job => {
                const dateObj = new Date(job.postedDate);
                const formattedDate = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

                const jobCard = document.createElement('div');
                jobCard.className = 'job-card';
                jobCard.innerHTML = `
                    <div class="job-header">
                        <div>
                            <h3 class="job-title">${job.title}</h3>
                            <div class="job-company">${job.company}</div>
                        </div>
                        <span class="job-date">Posted ${formattedDate}</span>
                    </div>
                    <div class="job-badges">
                        <span class="badge"><i class="fa-solid fa-location-dot"></i> ${job.location}</span>
                        <span class="badge"><i class="fa-solid fa-money-bill-wave"></i> ${job.salary}</span>
                    </div>
                    <div class="job-desc">
                        <p>${job.description}</p>
                    </div>
                    <button class="btn-apply" onclick="applyToJob('${job.company}', '${job.title}')">
                        Apply Now
                    </button>
                `;
                jobList.appendChild(jobCard);
            });
        } catch (error) {
            console.error('Error fetching jobs:', error);
        }
    }
});

// Global function to handle "Apply" clicks
function applyToJob(company, title) {
    // In a real application, this would redirect to an application form
    // or open a modal to upload a resume. For now, we simulate success:
    alert(`Your profile has been submitted to ${company} for the ${title} role!`);
}